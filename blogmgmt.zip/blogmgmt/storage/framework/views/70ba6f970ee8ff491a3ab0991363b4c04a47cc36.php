<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger">
        <strong><?php echo e(session('error')); ?></strong>
        </div>
    <?php endif; ?>
    <?php if(count($errors->all())): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">
        <strong><?php echo e($message); ?></strong>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <form class="row g-3 m-auto w-50" method="post" enctype="multipart/form-data">
        <div class="col-md-12">
            <div class="mb-3">
                <label for="title" class="form-label">title</label>
                <input type="text" class="form-control" id="title" placeholder="enter title" name="title" onkeyup="maxalert(this)" max="255">
            </div>
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="mb-3">
                <label for="description" class="form-label">description</label>
                <textarea class="form-control" id="description" name="description" rows="3" max="65535" onkeyup="maxalert(this)" ></textarea>
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">image</label>
                <input class="form-control" type="file" id="image" name="image">
            </div>
            <div class="mb-3">
                <label for="tags" class="form-label">tags</label>
                <input type="text" class="form-control" id="tags" placeholder="enter tags">
                <input type="hidden" id="hidden_tags" name="tags">
            </div>
            <div class="mb-3" id="preview-tags">
                
            </div>
            <div class="col-12">
                <button type="submit" class="btn btn-primary">Sign in</button>
            </div>
        </div>
    </form>
</div>
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>